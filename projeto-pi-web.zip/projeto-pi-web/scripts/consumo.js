async function buscarAPISincrono() {
    //let pRetorno = document.querySelector('#ModalLongoExemplo > div > div > div.modal-body');
    let pRetorno = document.querySelector('#retorno');
    pRetorno.textContent = '';
    let refeicao = document.getElementById('exampleFormControlSelect1');
    refeicao = refeicao.options[refeicao.selectedIndex].value;
    let objetivo = document.getElementById('exampleFormControlSelect2');
    objetivo = objetivo.options[objetivo.selectedIndex].value;
    let qtdeKcal = document.getElementById('exampleFormControlSelect3');
    qtdeKcal = qtdeKcal.options[qtdeKcal.selectedIndex].value;
    //let value = qtdeKcal.options[qtdeKcal.selectedIndex].value;
    console.log(refeicao);
    console.log(objetivo);
    console.log(qtdeKcal);
    let url = 'https://dio3gz5zll.execute-api.sa-east-1.amazonaws.com/api1/testlambda?refeicao=' +
        refeicao +
        '&objetivo=' + objetivo +
        '&kcal=' + qtdeKcal
    let retorno = await fetch(url, {
        'headers': { 'Content-type': 'application/json' },
        'method': 'GET',
        'mode': 'cors'
    });

    let retornoJSON = await retorno.json();
    alimentos = ''
    let elemento_pai = document.querySelector('#ModalLongoExemplo > div > div > div.modal-body'); //document.body;

    for (i = 0; i < retornoJSON.items.length; i++) {
        let titulo = document.createElement('p');
        titulo.appendChild(document.createTextNode('Alimento: ' + retornoJSON.items[i].Nome));
        elemento_pai.appendChild(titulo);
        let titulo2 = document.createElement('p');
        titulo2.appendChild(document.createTextNode('Proteinas: ' + retornoJSON.items[i].proteinas + 'g'));
        elemento_pai.appendChild(titulo2);
        let titulo3 = document.createElement('p');
        titulo3.appendChild(document.createTextNode('Carboidratos: ' + retornoJSON.items[i].carboidratos + 'g'));
        elemento_pai.appendChild(titulo3);
        let titulo4 = document.createElement('p');
        if (retornoJSON.items[i].porcao.tipo == 'padrao') {
            titulo4.appendChild(document.createTextNode('Quantidade: ' + retornoJSON.items[i].porcao.quantidade + 'g'));
        }
        if (retornoJSON.items[i].porcao.tipo == 'ml') {
            titulo4.appendChild(document.createTextNode('Quantidade: ' + retornoJSON.items[i].porcao.quantidade + 'ml'));
        }
        if (retornoJSON.items[i].porcao.tipo == 'unidade') {
            titulo4.appendChild(document.createTextNode('Quantidade: ' + retornoJSON.items[i].porcao.quantidade + ' unidade'));
        }

        elemento_pai.appendChild(titulo4);
        elemento_pai.appendChild(document.createElement('br'));
        elemento_pai.appendChild(document.createElement('br'));

    }
    let titulo4 = document.createElement('p');
    titulo4.appendChild(document.createTextNode('Valor enegético: ' + retornoJSON.kcal + 'Kcal'));
    elemento_pai.appendChild(titulo4);

}

function buscarAPIAssincrono() {
    let pRetorno = document.querySelector('#retorno');
    pRetorno.textContent = '';

    fetch('https://dio3gz5zll.execute-api.sa-east-1.amazonaws.com/api1/testlambda', {
            'headers': { 'Content-type': 'application/json' },
            'method': 'GET',
            'mode': 'cors'
        })
        .then(retorno => retorno.json())
        .then(json => {
            pRetorno.textContent = 'JSON inteiro:' + JSON.stringify(json);
            alert('Sodio: ' + json.sodio);
        })
}